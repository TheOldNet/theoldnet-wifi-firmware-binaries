I created this binaries repo because the end to end solution for modem and ethernet over serial comes from many different sources.

This package is designed to make it easy on the end user to grab one zip file and be able to do it all. 

I have created accomapnying documentation and videos to help the user along.

The sources in this package from:

microweb
mtcp
ethersl(get package name)
wifi-modem git-repo
esp_slip_router git repo


Get the ZIP File: https://theoldnet.com/downloads/serial-wifi-adapter-binaries.zip

Get your RS232 Serial to WIFI Adapter Here: https://theoldnet.com/store

TheOldNet WIFI Modem Emulator Firmware: https://github.com/ssshake/vintage-computer-wifi-modem/
MicroWeb Browser for DOS: https://github.com/jhhoward/MicroWeb
ESP_SLIP_Router Github: https://github.com/martin-ger/esp_slip_router
ESP_SLIP_Router DNS Issue: https://github.com/martin-ger/esp_slip_router/issues/17
mTCP Library: https://www.brutman.com/mTCP/
EtherSL via the Crynwr DOS Software Packet Drivers: http://www.ibiblio.org/pub/micro/pc-stuff/freedos/files/distributions/1.2/repos/pkg-html/crynwr.html
Dave's World article on SLIP in DOS: https://mcmackins.org/stories/dos-slip.html