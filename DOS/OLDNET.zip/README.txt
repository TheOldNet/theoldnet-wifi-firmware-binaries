##HOW TO FLASH

##WHICH FIRMWARE

##HOW TO CONFIGURE MODEM FIRMWARE

##HOW TO CONFIGURE ETHERNET FIRMWARE

Once connected to telnet press ALT + E and then ALT + N

##KNOWN ISSUES

- DNS does not work at all for ethernet firmware in DOS

##WHAT YOU NEED TO KNOW WHEN SWITCHING FIRMWARE

- You will loose all configuration settings such as your wifi SSID and PASSWORD as well as your preferred bit rate
- The bit rate will be reset to the default for the firmware. For the modem firmware it's 300 bps. For the ethernet firmware it's 115200 bps
- You must configure the ethernet firmware using TELNET on port 7777
- You must configure the modem firmware using a terminal program such as Telix and by issuing AT commands
