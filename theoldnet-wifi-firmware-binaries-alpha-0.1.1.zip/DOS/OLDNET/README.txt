Copy all of this to C:\OLDNET or update start.bat's path

Run START.BAT

Then configure the WIFI

TELNET.EXE 192.168.240.1 7777
ALT+E
ALT+N
set ssid MYSSID
set password MYPASSWORD
show
save
reset

Then ping 8.8.8.8